<?php
/**
 * Settings Lexicon Entries for ColorPicker
 *
 * @package colorpicker
 * @subpackage lexicon
 */
$_lang['setting_colorpicker.debug'] = 'Debug';
$_lang['setting_colorpicker.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
