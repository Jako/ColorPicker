<?php
/**
 * Settings Lexicon Entries for ColorPicker
 *
 * @package colorpicker
 * @subpackage lexicon
 */
$_lang['setting_colorpicker.debug'] = 'Débogage';
$_lang['setting_colorpicker.debug_desc'] = 'Enregistrer les informations de débogage dans le journal des erreurs du MODX.';
